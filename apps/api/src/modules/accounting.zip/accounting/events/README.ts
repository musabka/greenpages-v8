// This folder is reserved for in-process event handlers (NestJS providers)
// that consume domain events from other modules (Wallet, Commissions, Renewals, ...)
// and translate them into accounting journal entries.
